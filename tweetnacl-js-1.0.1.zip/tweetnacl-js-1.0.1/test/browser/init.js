var _ = require('tap-browser-color')();
